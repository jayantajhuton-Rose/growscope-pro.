# GrowScope Pro — Bangladesh launch plan

## Product scope
- Existing bilingual React/Vite application packaged for Android with Capacitor.
- Public website deployed from the same codebase through GitHub Pages.
- Core farmer information and tools remain free.
- Revenue is planned through clearly labelled sponsorships, business directory listings, and institutional partnerships.

## Current release truth
This repository is a prototype/starter, not a production-ready agricultural service. Market prices shown in the UI are illustrative sample data and must not be represented as live prices. Weather, AI chat, disease image analysis, field telemetry, irrigation hardware control, user accounts, cloud sync, notifications, analytics, and payments are not connected production services.

## Release gates before public promotion
1. Replace sample market data with a documented source, district/market, unit, collection time, and freshness indicator; otherwise keep the sample disclaimer visible.
2. Connect weather to a licensed/reliable provider and show location, timestamp, and limitations.
3. Replace canned AI responses with a tested service or label the feature as a demo; include safe escalation to local agricultural extension officers.
4. Do not claim crop disease diagnosis until image upload, model/service validation, confidence handling, and agronomist review/escalation are implemented.
5. Keep irrigation as a planner only unless a secure, tested hardware integration exists.
6. Add backend authentication, role-based access, data validation, backups, monitoring, and privacy controls before collecting personal farmer data.
7. Add a contact channel, privacy notice, terms, sponsor disclosure policy, and content correction process.
8. Test on multiple Android versions, low-cost devices, slow networks, and both Bangla and English.
9. Generate a signed release APK/AAB using a protected signing secret. Never commit keystores or passwords.
10. Complete Play Console account, app listing, data safety, content rating, and policy checks before Play Store release.

## Nationwide rollout approach
Prepare the product for nationwide access, but roll out data coverage transparently. Each record must carry source, district/market, unit, observation date/time, and status (verified, community-submitted, or illustrative). Do not imply that nationwide live data coverage exists until it is proven district by district.

## Sponsorship policy
- Clearly label paid placements as “Sponsored” / “স্পন্সরকৃত”.
- Sponsors cannot purchase favourable crop-health recommendations or suppress safety warnings.
- No unverified pesticide, seed, fertilizer, or yield claims.
- Publish a sponsor contact and correction/reporting channel.
- Obtain written permission for logos, product photos, and promotional claims.

## First 90 days
- Days 1–14: GitHub repository, build reproducibility, source audit, usability fixes.
- Days 15–30: website deployment, privacy/contact pages, device testing, recruit pilot users.
- Days 31–60: verify data providers and connect only services that pass testing; onboard initial business partners.
- Days 61–90: controlled nationwide public availability, publish coverage map/limitations, measure retention and sponsor performance.

## Initial commercial packages (test prices, not guaranteed market rates)
- Basic business profile: BDT 500/month.
- Featured profile: BDT 1,500/month.
- Sponsored educational content: BDT 3,000–5,000 per campaign.
- Institutional campaigns: quoted individually after a written scope.

Review prices after interviewing at least 15 potential business customers and 20 farmers.
