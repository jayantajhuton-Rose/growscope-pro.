# GitHub setup for GrowScope Pro

## Create your account
1. Open https://github.com and choose Sign up.
2. Register with an email address you control; verify the email.
3. Enable two-factor authentication and save recovery codes safely.
4. Do not share your password or recovery codes with anyone.

## Create the project repository
1. Sign in and open https://github.com/new.
2. Repository name: `growscope-pro`.
3. Description: `Bilingual agritech platform for Bangladesh — Android and web`.
4. Choose **Private** while development is in progress. Make the repository public only after checking that it contains no secrets or private data. GitHub Pages availability depends on plan and repository visibility.
5. Create repository. Do not add a README if uploading this prepared project with its own README.
6. On the repository page choose **Add file → Upload files**.
7. Extract the GrowScope ZIP on a computer and upload the contents of the extracted folder (not the ZIP itself), including the hidden `.github` folder. On Android, enable “Desktop site” if the upload interface hides options.
8. Commit to `main`.

## Publish the website
1. In the repository, open Settings → Pages.
2. Under Build and deployment, set Source to **GitHub Actions**.
3. Open Actions and watch `Deploy GrowScope Pro website`.
4. When successful, GitHub displays the Pages URL, usually `https://YOUR-USERNAME.github.io/growscope-pro/`.

## Build a test Android APK
1. Open Actions.
2. Choose `Build GrowScope Pro Android APK`.
3. Select Run workflow.
4. When successful, download the `GrowScope-Pro-debug-APK` artifact and install the APK on a test Android device.

## Important
- The debug APK is for testing only, not Play Store release.
- GitHub Pages is public hosting; never upload private user data, API keys, signing keys, or passwords.
- The repository must have GitHub Actions enabled.
- If the project uses a private repository on a plan that does not support private Pages, either keep the repo private and host the site on an appropriate static host, or deliberately make a sanitized repository public.
