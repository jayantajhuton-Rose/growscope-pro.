# GrowScope Pro

Bilingual (Bangla/English) agritech app prototype for Bangladesh, built with React, Vite and Capacitor Android.

## Current status
This is the continuation of the existing GrowScope Pro prototype. It is a pre-launch build, not a verified production agricultural service. Market-price figures are illustrative samples. Crop advice is educational. AI, image diagnosis, weather, field telemetry, irrigation hardware, accounts, cloud sync and live data are not yet connected production services.

## Local web build
Requires Node.js 20+.

```bash
npm install
npm run build
npm run dev
```

## Android debug build
Requires JDK 21 and Android SDK.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
- `.github/workflows/android-apk.yml` builds a debug APK on push or manual dispatch.
- `.github/workflows/deploy-pages.yml` builds and deploys the website to GitHub Pages on pushes to `main`.

For setup, read `docs/GITHUB-SETUP-BANGLA-EN.md`.
For the national launch gates and revenue plan, read `docs/LAUNCH-PLAN-BD.md`.

## Safety and commercial integrity
Keep essential farmer features free. Clearly disclose sponsored placements. Never label sample market prices as live. Do not present simulated AI output as a diagnosis. Do not connect physical irrigation equipment without secure hardware integration and safety testing.
