# Changelog

## 0.1.1 — launch preparation
- Preserved the existing React/Vite/Capacitor project and Android application ID.
- Added automated GitHub Pages deployment workflow.
- Added GitHub onboarding instructions and Bangladesh launch/revenue plan.
- Added pre-launch privacy and sponsorship policy placeholders.
- Re-labelled market prices as illustrative sample data, not live prices.
- Removed misleading simulated disease diagnosis and fake irrigation/pump success actions.
- Replaced unsupported weather/telemetry readings with clear demo/no-data states.
- Clarified that AI assistant output is a preview and not live agronomic advice.
