import React, { useState } from 'react';
import { 
  Sun, Cloud, Bell, Search, SlidersHorizontal, ArrowRight, Bookmark, 
  TrendingUp, MapPin, Calendar, Home as HomeIcon, 
  Plus, User, ChevronRight, Leaf, Droplets, ShoppingBag, 
  AlertTriangle, ArrowUpRight, ArrowDownRight, 
  ShieldAlert, Activity, Sparkles, X, Send, Globe
} from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('onboarding');
  const [activeTab, setActiveTab] = useState('home');
  const [selectedCrop, setSelectedCrop] = useState('Aman Rice');
  const [marketTab, setMarketTab] = useState('Overview');
  const [marketTimeframe, setMarketTimeframe] = useState('1D');
  const [activeModal, setActiveModal] = useState(null); 
  const [lang, setLang] = useState('en'); // 'en' or 'bn'

  const translations = {
    en: {
      appName: "GrowScope Pro",
      tagline: "Practical bilingual farming tools and knowledge for Bangladesh.",
      launch: "Launch Dashboard",
      footerTag: "Empowering smart agriculture across Bangladesh.",
      greeting: "Good morning,",
      aiAssistant: "AI Assistant",
      toolkit: "Agri Toolkit",
      cropAdvisor: "Crop Advisor",
      irrigation: "Irrigation",
      marketPrices: "Market Prices",
      pestScan: "Pest Scan",
      telemetry: "Field Telemetry",
      activeFields: "Sample: 2 Fields",
      fieldDesc: "Example only • not connected to a farm",
      tasks: "Priority Agronomy Tasks",
      knowledge: "Knowledge",
      markets: "Markets",
      profile: "Profile",
      home: "Home",
      downloadPdf: "Download Offline PDF Guide",
      liveFeed: "Sample Data"
    },
    bn: {
      appName: "গ্রোস্কোপ প্রো",
      tagline: "বাংলাদেশের কৃষকের জন্য ব্যবহারিক দ্বিভাষিক কৃষি-তথ্য ও টুলস।",
      launch: "ড্যাশবোর্ড শুরু করুন",
      footerTag: "বাংলাদেশের কৃষিকে স্মার্ট ও আধুনিক করে তুলুন।",
      greeting: "শুভ সকাল,",
      aiAssistant: "এআই সহকারী",
      toolkit: "কৃষি টুলকিট",
      cropAdvisor: "ফসল উপদেষ্টা",
      irrigation: "সেচ ব্যবস্থা",
      marketPrices: "বাজার দর",
      pestScan: "পোকা স্ক্যান",
      telemetry: "জমি পর্যবেক্ষণ",
      activeFields: "নমুনা: ২টি জমি",
      fieldDesc: "শুধু উদাহরণ • কোনো খামার সংযুক্ত নয়",
      tasks: "জরুরি কৃষি কাজ",
      knowledge: "জ্ঞানভাণ্ডার",
      markets: "বাজার",
      profile: "প্রোফাইল",
      home: "হোম",
      downloadPdf: "অফলাইন পিডিএফ গাইড ডাউনলোড করুন",
      liveFeed: "নমুনা তথ্য"
    }
  };

  const t = translations[lang];

  // Chat State
  const [chatMessages, setChatMessages] = useState([
    { role: 'assistant', text: lang === 'bn' ? "GrowScope সহকারী প্রিভিউতে স্বাগতম। এটি এখনো লাইভ খামার, আবহাওয়া বা সেন্সর ডেটার সঙ্গে যুক্ত নয়।" : "Welcome to the GrowScope assistant preview. This demo is not connected to live farm, weather, or sensor data." }
  ]);
  const [inputQuery, setInputQuery] = useState('');

  const cropsDatabase = {
    'Aman Rice': {
      scientific: 'Oryza sativa',
      season: lang === 'bn' ? 'জুন – জুলাই (বর্ষা)' : 'June – July (Monsoon)',
      duration: '120-140 Days',
      soil: lang === 'bn' ? 'দোআঁশ থেকে এঁটেল মাটি' : 'Clay loam to heavy clay',
      seedRate: '40 – 50 kg/ha',
      waterReq: lang === 'bn' ? 'মাঝারি – উচ্চ (প্লাবিত জমি)' : 'Moderate – High (Flooded paddy)',
      diseaseRisk: lang === 'bn' ? 'মাঝারি (ব্লাস্ট ও পাতা পোড়া রোগ)' : 'Medium (Blast, Bacterial Leaf Blight)',
      fertilizer: 'N-P-K: 80-40-30 kg/ha',
      optimalTemp: '25°C - 35°C',
      description: lang === 'bn' ? 'সিলেটের জলাভূমি ও পলিমাটির জন্য উপযুক্ত উচ্চ ফলনশীল আমন ধান জাত।' : 'High-yielding monsoon rice variety well suited to the Sylhet wetland and alluvial terrain.'
    },
    'Boro Rice': {
      scientific: 'Oryza sativa var. Boro',
      season: lang === 'bn' ? 'নভেম্বর – ডিসেম্বর (শীতকাল)' : 'November – December (Winter)',
      duration: '150-160 Days',
      soil: lang === 'bn' ? 'দোআঁশ মাটি' : 'Loamy to clay loam',
      seedRate: '35 – 45 kg/ha',
      waterReq: lang === 'bn' ? 'খুব বেশি (সেচযুক্ত)' : 'Very High (Irrigated)',
      diseaseRisk: lang === 'bn' ? 'কম – মাঝারি' : 'Low-Medium (Stem borer)',
      fertilizer: 'N-P-K: 120-60-40 kg/ha',
      optimalTemp: '20°C - 30°C',
      description: lang === 'bn' ? 'শুকনো মৌসুমের সেচনির্ভর ধান যা নিবিড় পানি ব্যবস্থাপনা ও রোদ প্রয়োজন করে।' : 'Dry-season irrigated rice requiring intensive water management and solar radiation.'
    },
    'Golden Jute': {
      scientific: 'Corchorus capsularis',
      season: lang === 'bn' ? 'মার্চ – এপ্রিল (প্রাক-বর্ষা)' : 'March – April (Pre-monsoon)',
      duration: '100-120 Days',
      soil: lang === 'bn' ? 'পলি দোআঁশ মাটি' : 'Alluvial loamy soils',
      seedRate: '6 – 8 kg/ha',
      waterReq: lang === 'bn' ? 'প্রচুর বৃষ্টিপাত প্রয়োজন' : 'High rainfall requirements',
      diseaseRisk: lang === 'bn' ? 'কম' : 'Low (Semi-aquatic resilience)',
      fertilizer: 'N-P-K: 60-30-30 kg/ha',
      optimalTemp: '24°C - 38°C',
      description: lang === 'bn' ? 'বাংলাদেশের প্রধান অর্থকরী ফসল, যা উষ্ণ ও আর্দ্র আবহাওয়া এবং প্রচুর আর্দ্রতায় ভালো জন্মে।' : 'Prime cash crop of Bangladesh, thriving in warm, humid weather with abundant moisture.'
    },
    'Potato (Diamant)': {
      scientific: 'Solanum tuberosum',
      season: lang === 'bn' ? 'নভেম্বর – ডিসেম্বর (রবি মৌসুম)' : 'November – December (Rabi)',
      duration: '90-100 Days',
      soil: lang === 'bn' ? 'বেলে দোআঁশ মাটি' : 'Sandy loam to loam',
      seedRate: '1,200 – 1,500 kg/ha',
      waterReq: lang === 'bn' ? 'মাঝারি (ড্রিপ সেচ)' : 'Moderate (Fumigation & Drip)',
      diseaseRisk: lang === 'bn' ? 'উচ্চ (লেট ব্লাইট ঝুঁকি)' : 'High (Late Blight risk in fog)',
      fertilizer: 'N-P-K: 150-90-100 kg/ha',
      optimalTemp: '15°C - 22°C',
      description: lang === 'bn' ? 'ঠান্ডা রাত এবং উর্বর নিষ্কাশন উপযোগী মাটির প্রয়োজন হয় এমন লাভজনক আলু জাত।' : 'High value tuber crop requiring cool nights and well-drained soil.'
    }
  };

  const marketPricesData = {
    'Overview': [
      { crop: lang === 'bn' ? 'ধান (আমন)' : 'Rice (Aman)', price: '৳2,450 / 100kg', change: '+2.6%', up: true, market: lang === 'bn' ? 'সিলেট কেন্দ্রীয় বাজার' : 'Sylhet Central' },
      { crop: lang === 'bn' ? 'পাট (কাঁচা)' : 'Jute (Raw)', price: '৳3,100 / 40kg', change: '+1.4%', up: true, market: lang === 'bn' ? 'ঢাকা পাইকারি' : 'Dhaka Wholesale' },
      { crop: lang === 'bn' ? 'আলু (ডায়মন্ড)' : 'Potato (Diamant)', price: '৳1,650 / 100kg', change: '-0.8%', up: false, market: 'Rangpur' },
      { crop: lang === 'bn' ? 'মসুর ডাল' : 'Lentil (Masoor)', price: '৳9,800 / 100kg', change: '+3.2%', up: true, market: 'Chattogram' }
    ],
    'Crops': [
      { crop: lang === 'bn' ? 'আমন ধান' : 'Aman Rice Paddy', price: '৳2,450', change: '+2.6%', up: true },
      { crop: lang === 'bn' ? 'বোরো ধান' : 'Boro Rice Paddy', price: '৳2,320', change: '+0.5%', up: true },
      { crop: lang === 'bn' ? 'কাঁচা পাট' : 'Raw Jute', price: '৳3,100', change: '+1.4%', up: true },
      { crop: lang === 'bn' ? 'সরিষা বীজ' : 'Mustard Seed', price: '৳6,200', change: '-1.2%', up: false }
    ],
    'Markets': [
      { market: lang === 'bn' ? 'সিলেট সদর' : 'Sylhet Sadar', price: '৳2,450', change: '+2.6%', up: true },
      { market: lang === 'bn' ? 'কাওরান বাজার, ঢাকা' : 'Kawran Bazar, Dhaka', price: '৳2,520', change: '+1.8%', up: true },
      { market: lang === 'bn' ? 'খাতুনগঞ্জ, চট্টগ্রাম' : 'Khatunganj, Chattogram', price: '৳2,410', change: '+0.9%', up: true },
      { market: lang === 'bn' ? 'বংশাল, রাজশাহী' : 'Bongshal, Rajshahi', price: '৳2,380', change: '-0.3%', up: false }
    ]
  };

  const handleSendMessage = () => {
    if (!inputQuery.trim()) return;
    const userMsg = inputQuery;
    setChatMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInputQuery('');

    setTimeout(() => {
      let reply = lang === 'bn' 
        ? "এটি পরীক্ষামূলক সহকারী, লাইভ কৃষিবিদ সেবা নয়। ফসল, বৃদ্ধির পর্যায়, এলাকা ও লক্ষণ জানান; গুরুত্বপূর্ণ সিদ্ধান্ত স্থানীয় কৃষি কর্মকর্তার সঙ্গে যাচাই করুন।"
        : "This is a demonstration assistant, not a live agronomist service. Please share your crop, growth stage, location and observed symptoms; verify important decisions with a qualified local agricultural officer.";
      
      if (userMsg.toLowerCase().includes('pest') || userMsg.toLowerCase().includes('disease') || userMsg.includes('পোকা')) {
        reply = lang === 'bn' 
          ? "এই প্রিভিউতে লাইভ আবহাওয়া বা ছবির ভিত্তিতে রোগের ঝুঁকি নির্ণয় করা যায় না। আক্রান্ত গাছের ছবি নিয়ে স্থানীয় কৃষি সম্প্রসারণ কর্মকর্তার পরামর্শ নিন; যাচাই ছাড়া কীটনাশক ব্যবহার করবেন না।"
          : "I cannot assess disease risk from live weather or image data in this preview. Photograph the affected plant and consult your local agricultural extension officer before applying any pesticide.";
      }
      setChatMessages(prev => [...prev, { role: 'assistant', text: reply }]);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#ecefe7] flex items-center justify-center p-0 sm:p-6 font-sans antialiased text-gray-800">
      {/* Mobile Device Frame */}
      <div className="w-full sm:w-[412px] h-screen sm:h-[860px] bg-[#f8f9f5] sm:rounded-[40px] shadow-2xl flex flex-col overflow-hidden relative border-0 sm:border-8 sm:border-[#1b4332]">
        
        {/* Status Bar */}
        <div className="bg-[#1b4332] text-white px-6 pt-3 pb-2 flex justify-between items-center text-xs font-medium tracking-wide select-none z-20">
          <span>9:41</span>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setLang(lang === 'en' ? 'bn' : 'en')}
              className="bg-emerald-800/80 hover:bg-emerald-700 text-emerald-100 px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 transition-colors"
            >
              <Globe className="w-3 h-3" /> {lang === 'en' ? 'বাংলা' : 'English'}
            </button>
            <div className="flex items-center gap-1">
              <span className="text-[10px]">5G</span>
              <div className="w-4 h-2.5 border border-white rounded-[2px] p-[1px] flex items-center">
                <div className="w-full h-full bg-white rounded-[1px]"></div>
              </div>
            </div>
          </div>
        </div>

        {/* SCREEN 1: ONBOARDING */}
        {currentScreen === 'onboarding' && (
          <div className="flex-1 flex flex-col justify-between bg-[#f8f9f5] relative overflow-hidden">
            <div className="absolute inset-0 pointer-events-none overflow-hidden flex flex-col justify-end">
              <div className="absolute bottom-0 w-full h-[45%] bg-[#2d5a3f] opacity-90 rounded-t-[60px] transform translate-y-10"></div>
              <div className="absolute bottom-0 w-full h-[35%] bg-[#1b4332] rounded-t-[80px]"></div>
              <div className="absolute bottom-40 left-6 text-[#95d5b2] opacity-60">
                <Leaf className="w-10 h-10 transform -rotate-12" />
              </div>
            </div>

            <div className="pt-16 px-8 text-center z-10 flex flex-col items-center">
              <div className="w-24 h-24 bg-white rounded-full shadow-lg flex items-center justify-center mb-6 border border-emerald-50">
                <div className="relative">
                  <div className="absolute -top-4 -left-2 text-amber-500 font-bold text-xs tracking-widest">☀</div>
                  <Leaf className="w-12 h-12 text-[#2d5a3f]" />
                  <div className="w-12 h-2 bg-emerald-600 rounded-full mt-1 opacity-80"></div>
                </div>
              </div>
              <h1 className="text-3xl font-extrabold text-[#1b4332] tracking-tight mb-2">{t.appName}</h1>
              <p className="text-gray-600 text-sm max-w-[260px] leading-relaxed">
                {t.tagline}
              </p>
              <div className="mt-4 rounded-full bg-emerald-50 border border-emerald-100 px-4 py-2 text-xs font-extrabold text-[#1b4332]">
                {lang === 'bn' ? 'কৃষকদের জন্য সম্পূর্ণ বিনামূল্যে' : 'Free for Farmers — Core Features'}
              </div>
            </div>

            <div className="flex justify-center items-center gap-2 z-10 my-auto">
              <div className="w-2.5 h-2.5 rounded-full bg-[#1b4332]"></div>
              <div className="w-2 h-2 rounded-full bg-emerald-300"></div>
              <div className="w-2 h-2 rounded-full bg-emerald-300"></div>
            </div>

            <div className="p-6 pb-10 z-10 flex flex-col gap-4">
              <button 
                onClick={() => { setCurrentScreen('home'); setActiveTab('home'); }}
                className="w-full bg-[#1b4332] hover:bg-[#143224] text-white py-4 px-6 rounded-2xl font-semibold flex items-center justify-between shadow-xl transition-all transform active:scale-95"
              >
                <span className="mx-auto pl-6">{t.launch}</span>
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                  <ArrowRight className="w-4 h-4 text-white" />
                </div>
              </button>
              <p className="text-center text-xs text-gray-400 font-medium">
                {t.footerTag}
              </p>
            </div>
          </div>
        )}

        {/* SCREEN 2: HOME DASHBOARD */}
        {currentScreen === 'home' && (
          <div className="flex-1 flex flex-col bg-[#f8f9f5] overflow-y-auto pb-24">
            <div className="bg-[#1b4332] text-white px-6 pt-4 pb-6 rounded-b-[32px] shadow-md">
              <div className="flex justify-between items-center mb-4">
                <button onClick={() => setActiveModal('profile')} className="p-2 -ml-2 rounded-full hover:bg-white/10">
                  <div className="space-y-1">
                    <div className="w-5 h-0.5 bg-white rounded-full"></div>
                    <div className="w-4 h-0.5 bg-white rounded-full"></div>
                    <div className="w-5 h-0.5 bg-white rounded-full"></div>
                  </div>
                </button>
                <div className="flex items-center gap-2">
                  <button onClick={() => setActiveModal('ai')} className="bg-emerald-700 hover:bg-emerald-600 px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-sm text-emerald-100">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" /> {t.aiAssistant}
                  </button>
                  <button onClick={() => setActiveModal('alerts')} className="p-2 rounded-full hover:bg-white/10 relative">
                    <Bell className="w-5 h-5" />
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-amber-400 rounded-full ring-2 ring-[#1b4332]"></span>
                  </button>
                </div>
              </div>

              <h2 className="text-2xl font-bold tracking-tight mb-3">
                {t.greeting}<br />Jayanta <span className="inline-block animate-bounce">🍃</span>
              </h2>

              {/* Weather Card */}
              <div className="bg-[#24503c] rounded-2xl p-4 flex items-center justify-between border border-white/5 shadow-inner">
                <div>
                  <div className="flex items-center gap-1.5 text-emerald-200 text-xs mb-1">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{lang === 'bn' ? 'সিলেট, বাংলাদেশ' : 'Sylhet, Bangladesh'} • Demo preview</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-extrabold tracking-tight">—°C</span>
                    <Sun className="w-6 h-6 text-amber-400 fill-amber-400" />
                  </div>
                  <p className="text-xs text-emerald-100 font-medium mt-0.5">{lang === 'bn' ? 'নমুনা আবহাওয়া • লাইভ ডেটা নয়' : 'Sample weather • not live data'}</p>
                </div>
                <div className="w-20 h-20 bg-emerald-800/40 rounded-full flex items-center justify-center relative overflow-hidden border border-white/10">
                  <Cloud className="w-10 h-10 text-emerald-200 absolute -top-1 right-2 opacity-80" />
                  <Sun className="w-8 h-8 text-amber-400 fill-amber-400 absolute bottom-2 left-2" />
                </div>
              </div>
            </div>

            <div className="px-6 pt-6 space-y-6">
              {/* Quick Access Grid */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="font-bold text-gray-900 text-sm">{t.toolkit}</h3>
                  <span className="text-xs font-semibold text-[#1b4332]">8 active</span>
                </div>
                <div className="grid grid-cols-4 gap-3">
                  <button 
                    onClick={() => setCurrentScreen('cropAdvisor')}
                    className="bg-white p-3 rounded-2xl flex flex-col items-center gap-2 shadow-sm border border-emerald-50 hover:border-emerald-200 transition-all group"
                  >
                    <div className="w-11 h-11 bg-emerald-50 rounded-xl flex items-center justify-center text-[#1b4332] group-hover:bg-[#1b4332] group-hover:text-white transition-colors">
                      <Leaf className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-medium text-gray-700 text-center leading-tight">{t.cropAdvisor}</span>
                  </button>

                  <button 
                    onClick={() => setActiveModal('irrigation')}
                    className="bg-white p-3 rounded-2xl flex flex-col items-center gap-2 shadow-sm border border-emerald-50 hover:border-emerald-200 transition-all group"
                  >
                    <div className="w-11 h-11 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <Droplets className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-medium text-gray-700 text-center leading-tight">{t.irrigation}</span>
                  </button>

                  <button 
                    onClick={() => setCurrentScreen('marketPrices')}
                    className="bg-white p-3 rounded-2xl flex flex-col items-center gap-2 shadow-sm border border-emerald-50 hover:border-emerald-200 transition-all group"
                  >
                    <div className="w-11 h-11 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                      <ShoppingBag className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-medium text-gray-700 text-center leading-tight">{t.marketPrices}</span>
                  </button>

                  <button 
                    onClick={() => setActiveModal('pest')}
                    className="bg-white p-3 rounded-2xl flex flex-col items-center gap-2 shadow-sm border border-emerald-50 hover:border-emerald-200 transition-all group"
                  >
                    <div className="w-11 h-11 bg-rose-50 rounded-xl flex items-center justify-center text-rose-600 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                      <ShieldAlert className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-medium text-gray-700 text-center leading-tight">{t.pestScan}</span>
                  </button>
                </div>
              </div>

              {/* Field Overview & Soil Telemetry */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="font-bold text-gray-900 text-sm">{t.telemetry}</h3>
                  <button onClick={() => setActiveModal('newField')} className="text-xs font-semibold text-[#1b4332] flex items-center gap-1">
                    <Plus className="w-3 h-3" /> {lang === 'bn' ? 'জমি যোগ করুন' : 'Add Field'}
                  </button>
                </div>
                <div className="bg-[#d8e6dc] rounded-2xl p-4 relative overflow-hidden shadow-inner border border-emerald-200/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xl font-black text-[#1b4332]">{t.activeFields}</div>
                      <div className="text-xs font-semibold text-[#2d5a3f]">{t.fieldDesc}</div>
                      <div className="text-[11px] text-gray-600 mt-0.5">Sample field • no sensor data</div>
                    </div>
                    <div className="w-16 h-14 bg-[#b9d5c2] rounded-xl flex items-center justify-center border border-emerald-300 shadow-sm">
                      <MapPin className="w-5 h-5 text-[#1b4332] animate-bounce" />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-emerald-300/40">
                    <div className="bg-white/80 p-2 rounded-xl text-center">
                      <span className="text-[10px] text-gray-500 font-bold block">{lang === 'bn' ? 'আর্দ্রতা' : 'MOISTURE'}</span>
                      <span className="text-xs font-extrabold text-[#1b4332]">—</span>
                    </div>
                    <div className="bg-white/80 p-2 rounded-xl text-center">
                      <span className="text-[10px] text-gray-500 font-bold block">{lang === 'bn' ? 'নাইট্রোজেন' : 'NITROGEN'}</span>
                      <span className="text-xs font-extrabold text-amber-700">—</span>
                    </div>
                    <div className="bg-white/80 p-2 rounded-xl text-center">
                      <span className="text-[10px] text-gray-500 font-bold block">{lang === 'bn' ? 'স্বাস্থ্য' : 'HEALTH'}</span>
                      <span className="text-xs font-extrabold text-emerald-700">—</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Upcoming Tasks */}
              <div>
                <h3 className="font-bold text-gray-900 text-sm mb-3">{t.tasks}</h3>
                <div className="space-y-2.5">
                  <div className="bg-white rounded-2xl p-4 shadow-sm border border-emerald-50 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-[#1b4332]">
                        <Leaf className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-gray-900">{lang === 'bn' ? 'নমুনা কাজ: সার প্রয়োগ' : 'Sample task: fertilizer application'}</h4>
                        <p className="text-[11px] text-gray-500">{lang === 'bn' ? 'ডেমো কাজ • বাস্তব সময়সূচি নয়' : 'Demo task • not a real schedule'}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2.5 py-1 rounded-full uppercase">
                      {lang === 'bn' ? 'শীঘ্রই' : 'Due'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 3: CROP ADVISOR */}
        {currentScreen === 'cropAdvisor' && (
          <div className="flex-1 flex flex-col bg-[#f8f9f5] overflow-y-auto pb-24">
            <div className="px-6 pt-4 pb-3 flex items-center justify-between border-b border-gray-100 bg-white">
              <button 
                onClick={() => setCurrentScreen('home')}
                className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center hover:bg-gray-100 transition-colors"
              >
                <span className="text-xl font-bold">←</span>
              </button>
              <h2 className="font-bold text-base text-gray-900">{lang === 'bn' ? 'ফসল জ্ঞানভাণ্ডার' : 'Crop Knowledge Base'}</h2>
              <button className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center hover:bg-gray-100">
                <Bookmark className="w-4 h-4 text-gray-700" />
              </button>
            </div>

            <div className="px-6 pt-4 space-y-5">
              <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                {Object.keys(cropsDatabase).map((crop) => (
                  <button
                    key={crop}
                    onClick={() => setSelectedCrop(crop)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                      selectedCrop === crop 
                        ? 'bg-[#1b4332] text-white shadow-md' 
                        : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    {crop}
                  </button>
                ))}
              </div>

              <div className="bg-white rounded-3xl p-5 shadow-sm border border-emerald-100 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-emerald-50 flex items-center justify-center text-2xl border border-emerald-100">
                      🌾
                    </div>
                    <div>
                      <h3 className="font-extrabold text-lg text-gray-900">{selectedCrop}</h3>
                      <p className="text-xs text-gray-500 italic">{cropsDatabase[selectedCrop].scientific}</p>
                      <span className="inline-block mt-1.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                        {lang === 'bn' ? 'প্রাথমিক পরামর্শ • যাচাই করুন' : 'General guidance • verify locally'}
                      </span>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-gray-600 leading-relaxed">
                  {cropsDatabase[selectedCrop].description}
                </p>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                    <span className="text-[10px] text-gray-400 font-bold block">{lang === 'bn' ? 'মৌসুম' : 'SEASON'}</span>
                    <span className="text-xs font-bold text-gray-800">{cropsDatabase[selectedCrop].season}</span>
                  </div>
                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                    <span className="text-[10px] text-gray-400 font-bold block">{lang === 'bn' ? 'সময়কাল' : 'DURATION'}</span>
                    <span className="text-xs font-bold text-gray-800">{cropsDatabase[selectedCrop].duration}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button 
                  onClick={() => alert(lang === 'bn' ? 'এই গাইড ডাউনলোড সুবিধা পরবর্তী সংস্করণে যুক্ত হবে।' : 'PDF guide downloads will be added in a future release.')}
                  className="w-full bg-[#1b4332] hover:bg-[#143224] text-white py-4 rounded-2xl font-semibold text-sm shadow-md transition-all active:scale-95"
                >
                  {t.downloadPdf}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 4: MARKET PRICES */}
        {currentScreen === 'marketPrices' && (
          <div className="flex-1 flex flex-col bg-[#f8f9f5] overflow-y-auto pb-24">
            <div className="px-6 pt-4 pb-3 flex items-center justify-between border-b border-gray-100 bg-white">
              <button 
                onClick={() => setCurrentScreen('home')}
                className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center hover:bg-gray-100 transition-colors"
              >
                <span className="text-xl font-bold">←</span>
              </button>
              <h2 className="font-bold text-base text-gray-900">{lang === 'bn' ? 'বাজার তথ্য' : 'Market Information'}</h2>
              <button className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center hover:bg-gray-100">
                <TrendingUp className="w-4 h-4 text-gray-700" />
              </button>
            </div>

            <div className="px-6 pt-4 space-y-5">
              <div className="bg-gray-200/80 p-1 rounded-full flex">
                {[
                  { key: 'Overview', label: lang === 'bn' ? 'সারসংক্ষেপ' : 'Overview' },
                  { key: 'Crops', label: lang === 'bn' ? 'ফসল' : 'Crops' },
                  { key: 'Markets', label: lang === 'bn' ? 'বাজার' : 'Markets' }
                ].map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setMarketTab(tab.key)}
                    className={`flex-1 py-2 text-xs font-semibold rounded-full transition-all ${
                      marketTab === tab.key 
                        ? 'bg-[#1b4332] text-white shadow-sm' 
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="bg-white rounded-3xl p-5 shadow-sm border border-emerald-50">
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <h3 className="font-extrabold text-base text-gray-900">{lang === 'bn' ? 'আমন ধান (প্রতি ১০০ কেজি)' : 'Rice Paddy (Aman)'}</h3>
                    <p className="text-xs text-gray-400">{lang === 'bn' ? 'উদাহরণমূলক তথ্য — লাইভ দর নয়' : 'Illustrative sample — not live market data'}</p>
                  </div>
                  <span className="text-xs font-bold bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-full">
                    {t.liveFeed}
                  </span>
                </div>

                <div className="flex items-baseline justify-between my-2">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-gray-900">৳2,450</span>
                    <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                      <ArrowUpRight className="w-3 h-3" /> 2.6%
                    </span>
                  </div>
                </div>

                <div className="w-full h-24 my-2 relative">
                  <svg className="w-full h-full overflow-visible" viewBox="0 0 300 80">
                    <path d="M 0,60 Q 50,45 100,50 T 200,30 T 300,15" fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" />
                  </svg>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-gray-900 text-sm mb-3">{lang === 'bn' ? 'উদাহরণমূলক বাজার তথ্য' : 'Illustrative Market Examples'}</h3>
                <div className="bg-white rounded-3xl p-2 shadow-sm border border-gray-100 divide-y divide-gray-50">
                  {marketPricesData[marketTab].map((item, index) => (
                    <div key={index} className="flex items-center justify-between py-3.5 px-3 hover:bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-800">
                          <ShoppingBag className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <span className="font-bold text-xs text-gray-900 block">{item.crop || item.market}</span>
                          <span className="text-[10px] text-gray-400">{item.market || 'Sample reference'}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-xs text-gray-900 block">{item.price}</span>
                        <span className={`text-[10px] font-bold inline-flex items-center gap-0.5 ${item.up ? 'text-emerald-600' : 'text-rose-500'}`}>
                          {item.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                          {item.change}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* AI MODAL */}
        {activeModal === 'ai' && (
          <div className="absolute inset-0 bg-black/55 z-50 flex flex-col justify-end backdrop-blur-sm">
            <div className="bg-white h-[80%] rounded-t-[32px] p-6 flex flex-col shadow-2xl">
              <div className="flex justify-between items-center pb-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-[#1b4332]">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-gray-900">{t.aiAssistant}</h3>
                    <p className="text-[10px] text-emerald-600 font-semibold">Demo • Bangla & English</p>
                  </div>
                </div>
                <button onClick={() => setActiveModal(null)} className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-500">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto py-4 space-y-3">
                {chatMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                      msg.role === 'user' 
                        ? 'bg-[#1b4332] text-white rounded-br-none' 
                        : 'bg-gray-100 text-gray-800 rounded-bl-none'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2 flex gap-2">
                <input 
                  type="text" 
                  value={inputQuery} 
                  onChange={(e) => setInputQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder={lang === 'bn' ? 'সার বা সেচ সম্পর্কে কিছু জিগ্যেস করুন...' : 'Ask about fertilizer, pests, irrigation...'} 
                  className="flex-1 bg-gray-100 px-4 py-3 rounded-2xl text-xs outline-none text-gray-800"
                />
                <button 
                  onClick={handleSendMessage}
                  className="w-11 h-11 bg-[#1b4332] text-white rounded-2xl flex items-center justify-center shadow-md hover:bg-[#143224]"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* PEST SCAN MODAL */}
        {activeModal === 'pest' && (
          <div className="absolute inset-0 bg-black/55 z-50 flex items-center justify-center p-6 backdrop-blur-sm">
            <div className="bg-white rounded-3xl p-6 w-full max-w-sm space-y-4 shadow-2xl text-center">
              <div className="w-14 h-14 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto">
                <ShieldAlert className="w-7 h-7" />
              </div>
              <h3 className="font-extrabold text-base text-gray-900">{lang === 'bn' ? 'এআই পোকা ও রোগ স্ক্যানার' : 'AI Pest & Disease Scanner'}</h3>
              <p className="text-xs text-gray-500 leading-relaxed">
                {lang === 'bn' ? 'ভবিষ্যৎ সংস্করণে ছবি-ভিত্তিক সহায়তা যুক্ত হবে। বর্তমানে এই সুবিধাটি পরীক্ষামূলক; এটি রোগ নির্ণয় করে না।' : 'Photo-based assistance is planned for a future release. This preview does not analyse images or diagnose crop disease.'}
              </p>
              <div className="border-2 border-dashed border-gray-200 rounded-2xl p-6 bg-gray-50 cursor-pointer">
                <p className="text-xs font-semibold text-[#1b4332]">{lang === 'bn' ? 'ছবি বিশ্লেষণ এখনো চালু হয়নি' : 'Image analysis is not connected yet'}</p>
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={() => setActiveModal(null)} className="flex-1 bg-gray-100 py-3 rounded-xl text-xs font-bold text-gray-700">{lang === 'bn' ? 'বাতিল' : 'Cancel'}</button>
                <button onClick={() => setActiveModal(null)} className="flex-1 bg-[#1b4332] text-white py-3 rounded-xl text-xs font-bold">{lang === 'bn' ? 'বন্ধ করুন' : 'Close'}</button>
              </div>
            </div>
          </div>
        )}

        {/* IRRIGATION MODAL */}
        {activeModal === 'irrigation' && (
          <div className="absolute inset-0 bg-black/55 z-50 flex items-center justify-center p-6 backdrop-blur-sm">
            <div className="bg-white rounded-3xl p-6 w-full max-w-sm space-y-4 shadow-2xl">
              <div className="flex justify-between items-center">
                <h3 className="font-extrabold text-base text-gray-900">{lang === 'bn' ? 'সেচ পরিকল্পনা' : 'Irrigation Planner'}</h3>
                <button onClick={() => setActiveModal(null)} className="text-gray-400"><X className="w-4 h-4"/></button>
              </div>
              <p className="text-xs text-gray-500">{lang === 'bn' ? 'ডেমো স্ক্রিন: পাম্প সংযুক্ত নয়' : 'Demo screen: no pump connected'}</p>
              <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-blue-900 block">{lang === 'bn' ? 'মাটির আর্দ্রতা: ডেটা সংযুক্ত নয়' : 'Soil moisture: no sensor data'}</span>
                  <span className="text-[11px] text-blue-700">{lang === 'bn' ? 'সেন্সর/আবহাওয়া ডেটা না থাকায় অনুমান নয়' : 'No prediction without sensor/weather data'}</span>
                </div>
                <Droplets className="w-6 h-6 text-blue-600" />
              </div>
              <button onClick={() => setActiveModal(null)} className="w-full bg-blue-600 text-white py-3.5 rounded-xl font-bold text-xs shadow-md">
                {lang === 'bn' ? 'বন্ধ করুন' : 'Close preview'}
              </button>
            </div>
          </div>
        )}

        {/* NEW FIELD MODAL */}
        {activeModal === 'newField' && (
          <div className="absolute inset-0 bg-black/55 z-50 flex items-center justify-center p-6 backdrop-blur-sm">
            <div className="bg-white rounded-3xl p-6 w-full max-w-sm space-y-4 shadow-2xl">
              <div className="flex justify-between items-center">
                <h3 className="font-extrabold text-base text-gray-900">{lang === 'bn' ? 'নতুন জমি নিবন্ধন' : 'Register New Field'}</h3>
                <button onClick={() => setActiveModal(null)} className="text-gray-400"><X className="w-4 h-4"/></button>
              </div>
              <div className="space-y-3">
                <div>
                  <label className="text-[10px] font-bold text-gray-500 block mb-1">{lang === 'bn' ? 'জমির নাম' : 'FIELD NAME'}</label>
                  <input type="text" defaultValue="Sylhet North Plot 3" className="w-full bg-gray-100 p-3 rounded-xl text-xs outline-none" />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-gray-500 block mb-1">{lang === 'bn' ? 'পরিমাণ (একর)' : 'SIZE (ACRES)'}</label>
                  <input type="text" defaultValue="5.2" className="w-full bg-gray-100 p-3 rounded-xl text-xs outline-none" />
                </div>
              </div>
              <button onClick={() => setActiveModal(null)} className="w-full bg-[#1b4332] text-white py-3.5 rounded-xl font-bold text-xs shadow-md">
                {lang === 'bn' ? 'বন্ধ করুন' : 'Close preview'}
              </button>
            </div>
          </div>
        )}

        {/* BOTTOM NAVIGATION BAR */}
        {currentScreen !== 'onboarding' && (
          <div className="absolute bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-gray-100 px-6 py-3 flex justify-between items-center z-30 shadow-lg">
            <button 
              onClick={() => { setCurrentScreen('home'); setActiveTab('home'); }}
              className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'home' ? 'text-[#1b4332]' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <HomeIcon className="w-5 h-5" />
              <span className="text-[10px] font-bold">{t.home}</span>
            </button>

            <button 
              onClick={() => { setCurrentScreen('cropAdvisor'); setActiveTab('fields'); }}
              className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'fields' ? 'text-[#1b4332]' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <Bookmark className="w-5 h-5" />
              <span className="text-[10px] font-bold">{t.knowledge}</span>
            </button>

            <button 
              onClick={() => setActiveModal('ai')}
              className="w-12 h-12 bg-[#1b4332] hover:bg-[#143224] text-white rounded-full flex items-center justify-center shadow-lg transform -translate-y-4 active:scale-95 transition-transform ring-4 ring-[#f8f9f5]"
            >
              <Sparkles className="w-6 h-6 text-amber-300" />
            </button>

            <button 
              onClick={() => { setCurrentScreen('marketPrices'); setActiveTab('alerts'); }}
              className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'alerts' ? 'text-[#1b4332]' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <TrendingUp className="w-5 h-5" />
              <span className="text-[10px] font-bold">{t.markets}</span>
            </button>

            <button 
              onClick={() => { setCurrentScreen('home'); setActiveTab('profile'); }}
              className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'profile' ? 'text-[#1b4332]' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <User className="w-5 h-5" />
              <span className="text-[10px] font-bold">{t.profile}</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
}